import { AlertCircle, Hospital, Skull, WormIcon as Virus } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function MetricsBar() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardContent className="flex items-center p-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
            <AlertCircle className="h-6 w-6 text-red-500" />
          </div>
          <div className="ml-4">
            <p className="text-sm font-medium text-muted-foreground">Confirmed Cases</p>
            <h3 className="text-2xl font-bold">124,587</h3>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center p-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-100">
            <Hospital className="h-6 w-6 text-amber-500" />
          </div>
          <div className="ml-4">
            <p className="text-sm font-medium text-muted-foreground">Hospitalizations</p>
            <h3 className="text-2xl font-bold">18,342</h3>
            <p className="text-xs text-muted-foreground">+8% from last month</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center p-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gray-100">
            <Skull className="h-6 w-6 text-gray-500" />
          </div>
          <div className="ml-4">
            <p className="text-sm font-medium text-muted-foreground">Deaths</p>
            <h3 className="text-2xl font-bold">1,247</h3>
            <p className="text-xs text-muted-foreground">+5% from last month</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center p-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
            <Virus className="h-6 w-6 text-blue-500" />
          </div>
          <div className="ml-4">
            <p className="text-sm font-medium text-muted-foreground">Predominant Serotype</p>
            <h3 className="text-2xl font-bold">DENV-2</h3>
            <p className="text-xs text-muted-foreground">Stable for 3 months</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
