"use client"

import { useState } from "react"
import { Filter, WormIcon as Virus, Download, Share2, Info, ZoomIn, ZoomOut, RefreshCw } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePickerWithRange } from "./date-range-picker"
import { Badge } from "@/components/ui/badge"
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { DengueMap } from "./dengue-map"
import { MetricsBar } from "./metrics-bar"
import { GenomicData } from "./genomic-data"
import { TrendAnalysis } from "./trend-analysis"

export default function DengueDashboard() {
  const [dateRange, setDateRange] = useState({
    from: new Date(2023, 0, 1),
    to: new Date(),
  })

  return (
    <SidebarProvider defaultOpen={true}>
      <div className="flex min-h-screen bg-background">
        <Sidebar variant="inset" collapsible="icon">
          <SidebarHeader className="flex items-center justify-between px-4 py-2">
            <div className="flex items-center space-x-2">
              <Virus className="h-6 w-6 text-red-500" />
              <h1 className="text-xl font-bold">Dengue Monitor</h1>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Filters</SidebarGroupLabel>
              <SidebarGroupContent className="space-y-4 px-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Date Range</label>
                  <DatePickerWithRange date={dateRange} setDate={setDateRange} />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Serotype</label>
                  <Select defaultValue="all">
                    <SelectTrigger>
                      <SelectValue placeholder="Select serotype" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Serotypes</SelectItem>
                      <SelectItem value="denv-1">DENV-1</SelectItem>
                      <SelectItem value="denv-2">DENV-2</SelectItem>
                      <SelectItem value="denv-3">DENV-3</SelectItem>
                      <SelectItem value="denv-4">DENV-4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Region</label>
                  <Select defaultValue="all">
                    <SelectTrigger>
                      <SelectValue placeholder="Select region" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Latin America</SelectItem>
                      <SelectItem value="brazil">Brazil</SelectItem>
                      <SelectItem value="mexico">Mexico</SelectItem>
                      <SelectItem value="colombia">Colombia</SelectItem>
                      <SelectItem value="venezuela">Venezuela</SelectItem>
                      <SelectItem value="peru">Peru</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Data Display</label>
                  <Select defaultValue="absolute">
                    <SelectTrigger>
                      <SelectValue placeholder="Select display type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="absolute">Absolute Numbers</SelectItem>
                      <SelectItem value="per-capita">Per Capita Rates</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button className="w-full">
                  <Filter className="mr-2 h-4 w-4" />
                  Apply Filters
                </Button>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-4">
              <SidebarGroupLabel>Export</SidebarGroupLabel>
              <SidebarGroupContent className="space-y-2 px-4">
                <Button variant="outline" className="w-full justify-start">
                  <Download className="mr-2 h-4 w-4" />
                  Export Data
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Share2 className="mr-2 h-4 w-4" />
                  Share Dashboard
                </Button>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <div className="flex-1 overflow-auto">
          <div className="container mx-auto p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold">Dengue Genomic & Epidemiological Dashboard</h1>
              <div className="flex items-center space-x-2">
                <SidebarTrigger />
                <Button variant="outline" size="sm">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Refresh Data
                </Button>
                <Button variant="outline" size="sm">
                  <Info className="h-4 w-4" />
                  <span className="sr-only">Information</span>
                </Button>
              </div>
            </div>

            <MetricsBar />

            <Card className="relative">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle>Geographic Distribution</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <ZoomIn className="h-4 w-4" />
                      <span className="sr-only">Zoom In</span>
                    </Button>
                    <Button variant="outline" size="sm">
                      <ZoomOut className="h-4 w-4" />
                      <span className="sr-only">Zoom Out</span>
                    </Button>
                    <Select defaultValue="heatmap">
                      <SelectTrigger className="h-8 w-[180px]">
                        <SelectValue placeholder="Map Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="heatmap">Heat Map</SelectItem>
                        <SelectItem value="choropleth">Choropleth</SelectItem>
                        <SelectItem value="bubble">Bubble Map</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <CardDescription>Showing dengue distribution across Latin America</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[500px] w-full rounded-md border">
                  <DengueMap />
                </div>
                <div className="mt-2 flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="bg-red-100">
                      DENV-1
                    </Badge>
                    <Badge variant="outline" className="bg-blue-100">
                      DENV-2
                    </Badge>
                    <Badge variant="outline" className="bg-green-100">
                      DENV-3
                    </Badge>
                    <Badge variant="outline" className="bg-yellow-100">
                      DENV-4
                    </Badge>
                  </div>
                  <div>Last updated: May 15, 2025</div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <GenomicData />
              <TrendAnalysis />
            </div>
          </div>
        </div>
      </div>
    </SidebarProvider>
  )
}
