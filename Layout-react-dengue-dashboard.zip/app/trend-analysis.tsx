import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function TrendAnalysis() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle>Trend Analysis</CardTitle>
          <CardDescription>Case evolution and seasonal patterns</CardDescription>
        </div>
        <Select defaultValue="6months">
          <SelectTrigger className="h-8 w-[150px]">
            <SelectValue placeholder="Time Period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1month">Last Month</SelectItem>
            <SelectItem value="3months">Last 3 Months</SelectItem>
            <SelectItem value="6months">Last 6 Months</SelectItem>
            <SelectItem value="1year">Last Year</SelectItem>
            <SelectItem value="5years">Last 5 Years</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="timeseries">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="timeseries">Time Series</TabsTrigger>
            <TabsTrigger value="seasonal">Seasonal</TabsTrigger>
            <TabsTrigger value="yoy">Year over Year</TabsTrigger>
          </TabsList>
          <TabsContent value="timeseries" className="space-y-4">
            <div className="mt-4 h-[300px] rounded-md border bg-muted/20 p-4">
              <div className="flex h-full flex-col items-center justify-center text-center">
                <p className="text-sm text-muted-foreground">Time series chart would appear here</p>
                <p className="mt-2 text-xs text-muted-foreground">Showing case evolution over time</p>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="seasonal" className="space-y-4">
            <div className="mt-4 h-[300px] rounded-md border bg-muted/20 p-4">
              <div className="flex h-full flex-col items-center justify-center text-center">
                <p className="text-sm text-muted-foreground">Seasonal pattern visualization would appear here</p>
                <p className="mt-2 text-xs text-muted-foreground">Showing monthly patterns across years</p>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="yoy" className="space-y-4">
            <div className="mt-4 h-[300px] rounded-md border bg-muted/20 p-4">
              <div className="flex h-full flex-col items-center justify-center text-center">
                <p className="text-sm text-muted-foreground">Year-over-year comparison would appear here</p>
                <p className="mt-2 text-xs text-muted-foreground">Comparing 2024 vs 2023 data</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
